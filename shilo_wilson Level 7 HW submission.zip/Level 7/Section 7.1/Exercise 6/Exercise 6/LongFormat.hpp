// Long Observer

#ifndef LONGOBSERVER_HPP
#define LONGOBSERVER_HPP

#include "Subject.hpp"
#include <iostream>


void LongFormat(int s)
{
	std::cout << "From Long: " << s << std::endl;
};
#endif