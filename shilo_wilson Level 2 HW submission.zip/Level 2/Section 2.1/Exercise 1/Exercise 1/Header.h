
/*
Basic Test class to test std::is_member_pointer


*/
#ifndef HEADER_H
#define HEADER_H

class Test
{

public:
	double val;
	Test() :val(3) {}
	
	double getVal()
	{
		return(val);
	}
};




#endif

